package com.gl.shop.TamarindFryVer03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TamarindFryVer03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
